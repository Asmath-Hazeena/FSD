document.addEventListener('DOMContentLoaded', async () => {
  const historyList = document.getElementById('historyList');
  try {
    const res = await fetch('/appointments');
    const data = await res.json();

    if (!data.length) {
      historyList.innerHTML = '<p>No appointments found.</p>';
      return;
    }

    historyList.innerHTML = '';
    data.forEach((appt) => {
      const entry = document.createElement('div');
      entry.className = 'receipt';
      entry.innerHTML = `
        <p><strong>👤 Name:</strong> ${appt.name}</p>
        <p><strong>📞 Phone:</strong> ${appt.phone}</p>
        <p><strong>🏥 Specialty:</strong> ${appt.specialty}</p>
        <p><strong>👨‍⚕️ Doctor:</strong> ${appt.doctor}</p>
        <p><strong>📅 Date:</strong> ${appt.date}</p>
        <p><strong>⏰ Time:</strong> ${appt.time}</p>
      `;
      historyList.appendChild(entry);
    });
  } catch (err) {
    historyList.innerHTML = '<p>Error loading appointments.</p>';
  }
});