const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const app = express();
const PORT = 3000;

const BOOKINGS_FILE = path.join(__dirname, 'bookings.json');

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

async function readBookings() {
  try {
    const data = await fs.readFile(BOOKINGS_FILE, 'utf8');
    return JSON.parse(data || '[]');
  } catch {
    return [];
  }
}

async function writeBookings(bookings) {
  await fs.writeFile(BOOKINGS_FILE, JSON.stringify(bookings, null, 2));
}

app.post('/book-appointment', async (req, res) => {
  const booking = req.body;
  if (!booking.name || !booking.phone || !booking.specialty || !booking.doctor || !booking.date || !booking.time) {
    return res.status(400).json({ message: 'Missing fields' });
  }
  booking.id = Date.now();
  const bookings = await readBookings();
  bookings.push(booking);
  await writeBookings(bookings);
  res.status(201).json({ message: 'Appointment booked', id: booking.id });
});

app.get('/appointments', async (req, res) => {
  const bookings = await readBookings();
  res.json(bookings);
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));